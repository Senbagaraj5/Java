package Day2;

public class Logical {

	public static void main(String[] args) {
		int num = 5;
		int num2 = 15;
		System.out.println(num==5&&num2==15);
		System.out.println(num==5||num2==16);
		System.out.println(num==5&num2==15);
		System.out.println(num==5|num2==16);
		System.out.println(num==4&&num2==15);
		System.out.println(num==4&&num2==16);
		System.out.println(num==5||num2==15);
		System.out.println(num==4||num2==15);
		System.out.println(num==4||num2==16);
		System.out.println(!(num>num2));
		

	}

}
