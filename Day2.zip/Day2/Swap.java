package Day2;

import java.util.Scanner;
public class Swap {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter the first value : ");
		int a = scan.nextInt();
		System.out.print("Enter the second value : ");
		int b = scan.nextInt();
		System.out.println("Before swapping : a = "+ a +",b = "+b);
		int temp = a;
		a=b;
		b=temp;
		System.out.println("After swapping : a = "+ a +",b ="+b);
		
		

	}

}
