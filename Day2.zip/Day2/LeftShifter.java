package Day2;

import java.util.Scanner;
public class LeftShifter {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter the num1 : ");
		int num1 = scan.nextInt();
		System.out.print("Enter the num2 : ");
		int num2 = scan.nextInt();
		System.out.println(num1<<num2);

	}

}
