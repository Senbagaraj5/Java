package Day2;

import java.util.Scanner;

public class AssignmentOperator {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter the num value:");
		int sum = scan.nextInt();
		sum/=3;
		System.out.print("Enter the Second value");
		int val = scan.nextInt();
		val+=3;
		System.out.println(sum);
		System.out.println(val);

	}

}
