package Day2;
public class Sum{
public static void main(String [] args){
int sum = 220;
sum%=100;
System.out.println(sum);
}
}