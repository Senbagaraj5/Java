package Day2;

import java.util.Scanner;
public class SwapOperator {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter the first value : ");
		int num1 = scan.nextInt();
		System.out.print("Entet the second value : ");
		int num2 = scan.nextInt();
		System.out.println("Before Swapping : a = "+ num1 +",b = "+ num2);
		num1 = num1^num2;
		num2 = num1^num2;
		num1 = num1^num2;
		System.out.println("After Swapping : a = "+num1 +", b = "+ num2);
		

	}

}
