package Day2;

import java.util.Scanner;

public class RelationOperator {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter the Num1 value:");
		int num1 = scan.nextInt();
		System.out.print("Enter the Num2 value:");
		int num2 = scan.nextInt();
		System.out.println(num1!=num2);
		System.out.println(num1<num2);
		System.out.println(num1>num2);
		System.out.println(num1==num2);
		System.out.println(num1<=num2);
		System.out.println(num1>=num2);
		

	}

}
