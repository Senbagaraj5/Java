package Day2;
import java.util.Scanner;

public class Ternary {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter the value:");
		int value = scan.nextInt();
		System.out.print("Enter the value2:");
		int value2= scan.nextInt();
		int div=((value>value2)?value:value2);
		System.out.println(div);
		

	}

}