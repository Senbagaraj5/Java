package Day7;

public class Task {

	public static void main(String[] args) {
				String str="Senbagaraj";
				String str1  ="Senbagaraj";
				String str2=new String("Senbagaraj");
				String str3=new String("yellowmatics");
				System.out.println(str==str1);
				System.out.println(str.equals(str2));
				System.out.println(str.equalsIgnoreCase(str2));
				System.out.println(str.length());
				System.out.println(str);
				String word[] = str.split(" ");
				for(String var:word)
				{
					System.out.println(var);
				}
				System.out.println(str3.substring(5));
				System.out.println(str3.contains("kis"));	
				System.out.println(str3.endsWith("cs"));
				System.out.println(str3.charAt(3));
				System.out.println(str3.concat("gether"));
				
			}


	}


