package Day7;

public class Task3
{

		public String display()
		{
			String name = "Senbagaraj.";
			return name;
		}
		public static void main(String[] args) 
		{
			Task3 obj = new Task3();
			String res = obj.display();
			System.out.println(res);
	    }
}
