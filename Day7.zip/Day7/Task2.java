package Day7;

import java.util.Scanner;
public class Task2 {

	public int add(int a, int b)
	{
		int sum=a+b;
		return sum;
	}
	public static void main(String[] args) {
		Task2 obj = new Task2();
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();
		int num2 = scan.nextInt();
	}

}
	