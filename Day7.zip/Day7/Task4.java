package Day7;

import java.util.Scanner;
public class Task4 {

	public static void main(String[] args) {
		
		        Scanner sc = new Scanner(System.in);
		        String str = sc.nextLine(); 
		        char[] ch = str.toCharArray();

		        for (int i = 0; i < ch.length; i++) {
		            if (ch[i] >= 'A' && ch[i] <= 'Z') {
		          
		                ch[i] = (char)(ch[i] + 32);
		            } else if (ch[i] >= 'a' && ch[i] <= 'z') {
		                
		                ch[i] = (char)(ch[i] - 32);
		            }
		        }

		        System.out.println(new String(ch)); 
		}

	}


