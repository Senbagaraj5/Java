package Day5;

import java.util.*;
public class Task {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int size = scan.nextInt();
		int arr[] =new int[size];
		for(int i=0;i<arr.length;i++) {
			arr[i]=scan.nextInt();
		}
		int max = arr[0];
		for(int i=1;i<arr.length;i++) {
			if(max<arr[i]) {
				max=arr[i];
			}
		}
		System.out.println(max);

	}

}
