package Day5;

import java.util.*;
public class Palimdrome {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		int a = 0;
		int b=num;
		while(num>0) {
			int temp = num%10;
			a=a*10+temp;
			num=num/10;
		}
		if(b==a) {
			System.out.println("It is an Polindrome.");
		}
		else {
			System.out.println("Not a Polindrome");
		}

	}

}
