package Day9;

class Bird
{
	String color = "Purple";
	void eat()
	{
		System.out.println("Eating");
	}
}
class Dog extends Bird
{
	void Bark()
	{
		System.out.println("Barking....");
	}
	void display()
	{
		super.eat();
		Bark();
	}
}
public class Task6 {

	public static void main(String[] args) {
		Dog obj = new Dog();
		obj.display();

	}

}
