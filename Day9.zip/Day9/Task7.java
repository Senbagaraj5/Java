package Day9;

public class Task7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
