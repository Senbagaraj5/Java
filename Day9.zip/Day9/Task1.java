package Day9;
// Interface

interface Animal
{
	void sound();
	default void run()
	{
		
			System.out.println("Running");
	}

static void eat()
   {
	System.out.println("Eatting");
   }
}
class dog implements Animal
{
	public void sound()
	{
		System.out.println("Bow");
	}
}
public class Task1
{

	public static void main(String[] args)
	{
		
		dog obj = new dog();
		obj.sound();

	}

}
