package Day9;
//Abstract class

abstract class Bike
{
	abstract void run();
}
class Honda extends Bike
{
	void run() 
	{
		System.out.println("Vehicle");
	}

void play() 
   {
	System.out.println("Playing");
   }
}
public class Task2 
{

	public static void main(String[] args)
	{
		
		Bike obj = new Honda();
		obj.run();
		Honda obj1 = new Honda();
		obj1.play();
		

	}

}
