package Day9;
// Super Keyword

class Bird
{
	String color = "Purple";
}
class Dog extends Bird
{
	String color = "White";
	void display()
	{
		System.out.println(color);
		System.out.println(super.color);
	}
}
public class Task5
{

	public static void main(String[] args) 
	{
	Dog obj = new Dog();
	obj.display();

	}

}
