package Day9;
//multiple inheritance

interface print
{
	void display();
}
interface copy
{
	void show();
}
class xerox implements print, copy
{
	public void display()
	{
		System.out.println("Displaying..........................");
	}
	public void show()
	{
		System.out.println("Showing..............................................");
	}
}
public class Task4 
{

	public static void main(String[] args) 
	{
	xerox obj = new xerox();
	obj.display();
	obj.show();
	}

}
