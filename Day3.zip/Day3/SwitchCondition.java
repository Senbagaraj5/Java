package Day3;

import java.util.*;
public class SwitchCondition {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter the Ascii value upto 65 to 90 : ");
		int num = scan.nextInt();
		switch(num){
			
		case 'A':{
			System.out.println("The given Ascii vaule letter A.");
			break;
		}
		case 'B':{
			System.out.println("The given Ascii vaule letter B.");
			break;
		}
		case 'C':{
			System.err.println("The given Ascii vaule letter C.");
			break;
		}
		case 'D':{
			System.out.println("The given Ascii vaule letter D.");
			break;
		}
		case 'E':{
			System.out.println("The given Ascii vaule letter E.");
			break;
		}
		case 'F':{
			System.out.println("The given Ascii vaule letter F.");
			break;
		}
		case 'G':{
			System.out.println("The given Ascii vaule letter G.");
			break;
		}
		case 'H':{
			System.out.println("The given Ascii vaule letter H.");
			break;
		}
		case 'J':{
			System.out.println("The given Ascii vaule letter J.");
			break;
		}
		case 'K':{
			System.out.println("The given Ascii vaule letter K.");
			break;
		}
		case 'L':{
			System.out.println("The given Ascii vaule letter L.");
			break;
		}
		case 'M':{
			System.out.println("The given Ascii vaule letter M.");
			break;
		}
		case 'N':{
			System.out.println("The given Ascii vaule letter N.");
			break;
		}
		case 'O':{
			System.out.println("The given Ascii vaule letter O.");
			break;
		}
		case 'P':{
			System.out.println("The given Ascii vaule letter P.");
			break;
		}
		case 'Q':{
			System.out.println("The given Ascii vaule letter Q.");
			break;
		}
		case 'R':{
			System.out.println("The given Ascii vaule letter R.");
			break;
		}
		case 'S':{
			System.out.println("The given Ascii vaule letter S.");
			break;
		}
		case 'T':{
			System.out.println("The given Ascii vaule letter T.");
			break;
		}
		case 'U':{
			System.out.println("The given Ascii vaule letter U.");
			break;
		}
		case'V':{
			System.out.println("The given Ascii vaule letter V.");
			break;
		}
		case 'W':{
			System.out.println("The given Ascii vaule letter W.");
			break;
		}
		case 'X':{
			System.out.println("The given Ascii vaule letter X.");
			break;
		}
		case 'Y':{
			System.out.println("The given Ascii vaule letter Y.");
			break;
		}
		case 'Z':{
			System.out.println("The given Ascii vaule letter Z.");
			break;
		}
		default:{
			System.out.println("Not Required.");
			break;
		}

	}

	}
	}
