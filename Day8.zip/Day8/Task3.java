package Day8;


public class Task3 {
	
	int rollno = 100;
	String name = "Senbagaraj";
	static String collegename = "Zion";
	
	void display(int a, String name) {
		System.out.println(a+" "+name+" "+collegename);
	}

	public static void main(String[] args) {
		
		Task3 obj = new Task3();
		Task3.collegename = "Mount";
		obj.display(100, "Senbagaraj");
		obj.display(127, "Yaseen Affan");
		obj.display(107, "Siva Balan");
		obj.display(89,"Kishore");
		obj.display(45,"Dharshan");
		

	}

}
