package Day8;
//constructor
public class Task5 {
	
	int age;
	String name;
	Task5(){
		System.out.println("Hi.");
	}
	Task5(int a,String str){
		age =a;
		name = str;
		
	}
	void display() {
		System.out.println(age+" "+name);
	}

	public static void main(String[] args) {
		Task5 obj = new Task5();
		obj.age=19;
		obj.name="Senbagaraj";
		
		System.out.println(obj.name);
		System.out.println(obj.age);
	}

}
