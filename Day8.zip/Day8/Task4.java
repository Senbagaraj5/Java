package Day8;

public class Task4 {

	String hotelname;
	String food;
	int price;
	
	public static void main(String[] args) {
		
		Task4 obj = new Task4();
		System.out.println(obj.hotelname);
		Task4 obj1 = new Task4();
		obj1.price = 20;
		System.out.println(obj1.price);
		
		obj.price = 50;
		obj.hotelname="Maran";
		System.out.println(obj.price);
		System.out.println(obj.hotelname);
		

	}

}
