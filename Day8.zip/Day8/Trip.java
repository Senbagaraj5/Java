package Day8;

public class Trip {
	
	String place;
	String hotel;
	int price;
	String nextdistination;
	
        public static void main(String[] args) {
		Trip obj = new Trip();
		obj.place = "Japan";
		obj.hotel = "Tokyo Hotel";
		obj.price = 50000;
		obj.nextdistination = "Russia";
		System.out.println("Triping Place: "+obj.place);
		System.out.println("Staying Hotel: "+obj.hotel );
		System.out.println("Budget: "+obj.price);
		System.out.println("Next Distination: "+obj.nextdistination );
	}

}
        





