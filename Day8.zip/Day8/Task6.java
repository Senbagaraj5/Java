package Day8;

		public class Task6{

			int age;
			String name;
			Task6(int age,String name)
			{
				this.age=age;
				this.name=name;
			}
			void display()
			{
				System.out.println(age+" "+name);
			}
			public static void main(String[] args) 
			{
				Task5 obj=new Task5(5,"Senbagaraj");
				obj.display();
				

			}

		}

	
