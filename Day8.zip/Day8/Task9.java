package Day8;

//higher logical;
class Dad3{
	void property() {
		System.out.println("house,lands,villa");
	}
}
class Son3 extends Dad3
{
	void show(){
		System.out.println("bike");
	}
}
class Daughter3 extends Son3
{
	void display() {
		System.out.println("jewel");
	}
	}
	public class Task9{
	
	public 
	static void main(String[] args) {
		
		Daughter3 obj1=new  Daughter3();
		obj1.show();
		obj1.display();
		obj1.property();
		
		
		
		

	}

}