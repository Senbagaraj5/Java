package Day8;

class grandpa
{
	void display()
	{
		System.out.println("VILLA");
		
	}
}
class dad extends grandpa
{
	void property()
	{
		System.out.println("House,Lands");
	}
}
class son extends dad
{
	void show()
	{
		System.out.println("Bike");
	}
}
public class Task8{
	public static void main(String[] args) {
		son obj = new son();
		obj.display();
		obj.property();
		obj.show();
	}
}