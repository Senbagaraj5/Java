package Day8;
//static keyword
public class Task1 {
	
	int rollno=100;
	String name = "Senbagaraj";
	static String collegename="Zion";
	
	void display(int a, String name){
	System.out.println(a+" "+name+" "+collegename);
	}
	

	public static void main(String[] args) {
		
		Task1 obj = new Task1();
//		System.out.println(obj.rollno);
		System.out.println(Task1.collegename);
		Task1.collegename="Mount";
		obj.display(100,"Senbagraj");
		obj.display(126,"Yaseen Affan");
		obj.display(107,"Siva");
		
		                  

	}

}
