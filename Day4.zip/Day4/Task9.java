package Day4;

import java.util.*;
public class Task9 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int str = scan.nextInt();
		int sum=0;
		int dis=0;
		while(str>0) {
			int temp = str%10;
			sum = sum+temp;//12
			str = str/10;
		}
		int val = sum%10;
		int val2 = sum/10;
		dis = val+val2;
		System.out.println(dis);
		


	}

}
