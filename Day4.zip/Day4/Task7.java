package Day4;

import java.util.*;
public class Task7 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int str = scan.nextInt();
		int fact = 1;
		for(int i=1;i<=str;i++) {
			fact = fact*i;
		
		}
		System.out.println(fact);

	}

}
