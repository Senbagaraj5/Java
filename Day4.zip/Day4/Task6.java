package Day4;

import java.util.*;
public class Task6 {

	public static void main(String[] args) {
		Scanner str = new Scanner(System.in);
		int a = str.nextInt();
		int b = str.nextInt();
		int gcd = 0;
		int min=(a<b)?a:b;
		for(int i = min;i>0;i--) {
			if(a%i==0&&b%i==0) {
				gcd=i;
				break;
			}
			
		}
		System.out.println(gcd);
	}

}
