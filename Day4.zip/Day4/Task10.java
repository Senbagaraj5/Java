package Day4;

import java.util.*;
public class Task10 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int sum = scan.nextInt();
		int rev = 0;
		while(sum>0) {
			int temp = sum%10;
			 rev = rev*10+temp;
			 sum = sum/10;
		}
		System.out.println(rev);
	}

}
