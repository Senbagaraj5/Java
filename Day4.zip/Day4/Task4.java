package Day4;

import java.util.*;

public class Task4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int even = 0;
		for(int i =1;i<=a;i++) {
			if(a%i==0) {
				even++;
			}
		}
		System.out.println("Count :"+even);		

	}

}
