package Day4;

import java.util.*;

public class Task1 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();
		for(int i=0;i<=num;i+=2) {
			System.out.println(i);
			
		}

	}

}
