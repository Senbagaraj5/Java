package Day4;

import java.util.*;
public class Task3 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int i = scan.nextInt();
		int j = scan.nextInt();
		int even = 0;
		for(int a=i ; a<=j; a++) {
			if(a%2!=0) {
				even++;
			}
		
		}
		System.out.println("Total count of even value:"+even);
		
			
		
	}
}
