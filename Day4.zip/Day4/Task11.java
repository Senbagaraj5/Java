package Day4;

import java.util.*;
public class Task11 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();
		do {
			System.out.println(num);
			num++;
		}while(num!=100);
	}

}
