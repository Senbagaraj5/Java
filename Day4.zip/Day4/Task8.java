package Day4;

import java.util.*;
public class Task8 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();
		while(num>0 ){
			System.out.println(num);
			num--;
		}
		
	}

}
