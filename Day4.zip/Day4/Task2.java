package Day4;

public class Task2 {

	public static void main(String[] args) {
		int num = 10;
		for(int i = num; i>=0; i-=2 ) {
			System.out.println(i);
		}

	}

}
